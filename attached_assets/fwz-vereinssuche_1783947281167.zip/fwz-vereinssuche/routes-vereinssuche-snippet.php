<?php

/**
 * In routes/web.php ergänzen (zusätzlich zu den bereits vorhandenen Routen).
 */

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/vereine/suche', [HomeController::class, 'vereineSuche'])->name('vereine.suche');
