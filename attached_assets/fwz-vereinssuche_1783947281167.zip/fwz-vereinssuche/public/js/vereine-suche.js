/**
 * vereine-suche.js
 * Barrierefreie Live-Suche/Autocomplete für das Vereinsverzeichnis.
 * ARIA-Combobox-Muster: Eingabefeld + Listbox mit Vorschlägen, per Maus
 * und Tastatur (Pfeiltasten, Enter, Escape) bedienbar. Dieselbe Antwort
 * aus dem Suchendpunkt aktualisiert sowohl die Vorschlagsliste als auch
 * das darunterliegende Ergebnis-Grid.
 */
(function () {
  "use strict";

  var input = document.getElementById("vereine-such-eingabe");
  var listbox = document.getElementById("vereine-listbox");
  var grid = document.getElementById("vereine-ergebnisse");
  var status = document.getElementById("vereine-status");
  var searchBtn = document.getElementById("vereine-such-button");
  var chipsWrap = document.getElementById("vereine-chips");
  if (!input || !listbox || !grid) return;

  var searchUrl = grid.dataset.searchUrl || "/vereine/suche";
  var currentKategorie = "alle";
  var activeIndex = -1;
  var debounceTimer = null;
  var lastResults = [];

  function placeholderLogo() {
    return grid.dataset.placeholderLogo || "/img/placeholder-verein-logo.svg";
  }

  function renderCard(verein) {
    var logo = verein.logo || placeholderLogo();
    var alt = verein.logo ? "Logo von " + verein.name : "Kein Vereinslogo hinterlegt";
    var card = document.createElement("div");
    card.className = "org-card";
    card.innerHTML =
      '<img class="org-logo" src="' + logo + '" alt="' + escapeHtml(alt) + '" width="56" height="56" loading="lazy">' +
      '<div class="name">' + escapeHtml(verein.name) + "</div>" +
      '<div class="place">' + escapeHtml(verein.ort || "") + "</div>";
    return card;
  }

  function escapeHtml(str) {
    var div = document.createElement("div");
    div.textContent = str == null ? "" : str;
    return div.innerHTML;
  }

  function renderGrid(results) {
    grid.innerHTML = "";
    if (results.length === 0) {
      var empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "Keine Vereine gefunden. Versucht einen anderen Suchbegriff oder eine andere Kategorie.";
      grid.appendChild(empty);
      return;
    }
    results.forEach(function (v) {
      grid.appendChild(renderCard(v));
    });
  }

  function renderListbox(results) {
    listbox.innerHTML = "";
    activeIndex = -1;
    var subset = results.slice(0, 6);
    if (subset.length === 0) {
      listbox.hidden = true;
      input.setAttribute("aria-expanded", "false");
      return;
    }
    subset.forEach(function (v, i) {
      var li = document.createElement("li");
      li.setAttribute("role", "option");
      li.id = "vereine-option-" + i;
      li.className = "vereine-listbox__option";
      li.textContent = v.name + (v.ort ? " — " + v.ort : "");
      li.addEventListener("mousedown", function (e) {
        e.preventDefault();
        selectOption(v);
      });
      listbox.appendChild(li);
    });
    listbox.hidden = false;
    input.setAttribute("aria-expanded", "true");
  }

  function selectOption(verein) {
    input.value = verein.name;
    listbox.hidden = true;
    input.setAttribute("aria-expanded", "false");
    input.removeAttribute("aria-activedescendant");
  }

  function setStatus(count) {
    if (!status) return;
    status.textContent = count === 0
      ? "Keine Vereine gefunden."
      : count + (count === 1 ? " Verein gefunden." : " Vereine gefunden.");
  }

  function search() {
    var params = new URLSearchParams();
    if (input.value.trim() !== "") params.set("q", input.value.trim());
    params.set("kategorie", currentKategorie);

    fetch(searchUrl + "?" + params.toString(), {
      headers: { "Accept": "application/json" },
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        lastResults = data.results || [];
        renderGrid(lastResults);
        renderListbox(lastResults);
        setStatus(lastResults.length);
      })
      .catch(function () {
        setStatus(0);
      });
  }

  function debouncedSearch() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(search, 300);
  }

  input.addEventListener("input", debouncedSearch);

  input.addEventListener("keydown", function (e) {
    var options = listbox.querySelectorAll('[role="option"]');
    if (listbox.hidden || options.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      activeIndex = Math.min(activeIndex + 1, options.length - 1);
      updateActiveOption(options);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      activeIndex = Math.max(activeIndex - 1, 0);
      updateActiveOption(options);
    } else if (e.key === "Enter") {
      if (activeIndex >= 0 && options[activeIndex]) {
        e.preventDefault();
        selectOption(lastResults[activeIndex]);
      } else {
        listbox.hidden = true;
      }
    } else if (e.key === "Escape") {
      listbox.hidden = true;
      input.setAttribute("aria-expanded", "false");
    }
  });

  function updateActiveOption(options) {
    options.forEach(function (opt, i) {
      opt.setAttribute("aria-selected", String(i === activeIndex));
      opt.classList.toggle("is-active", i === activeIndex);
    });
    if (activeIndex >= 0) {
      input.setAttribute("aria-activedescendant", options[activeIndex].id);
    } else {
      input.removeAttribute("aria-activedescendant");
    }
  }

  document.addEventListener("click", function (e) {
    if (!listbox.contains(e.target) && e.target !== input) {
      listbox.hidden = true;
      input.setAttribute("aria-expanded", "false");
    }
  });

  if (searchBtn) searchBtn.addEventListener("click", search);

  if (chipsWrap) {
    chipsWrap.querySelectorAll(".chip").forEach(function (chip) {
      chip.addEventListener("click", function () {
        chipsWrap.querySelectorAll(".chip").forEach(function (c) { c.setAttribute("aria-pressed", "false"); });
        chip.setAttribute("aria-pressed", "true");
        currentKategorie = chip.dataset.kategorie;
        search();
      });
    });
  }
})();
