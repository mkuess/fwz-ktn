<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * HINWEIS: Falls dieses Model bei euch schon existiert (aus der Filament-
 * CategoryResource), nicht überschreiben — nur prüfen, ob die
 * organisations()-Relation unten schon vorhanden ist, sonst ergänzen.
 */
class Category extends Model
{
    protected $fillable = ['name', 'slug', 'color', 'icon', 'sort_order'];

    public function organisations(): BelongsToMany
    {
        return $this->belongsToMany(Organisation::class, 'organisation_category');
    }
}
