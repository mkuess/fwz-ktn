<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Hash;

/**
 * WICHTIG: Dies ist die bereits bestehende Organisation.php (aus dem
 * Registrierungs-Feature) mit EINER Ergänzung: der categories()-Relation
 * ganz unten. Falls euer echtes Model schon existiert, dort NUR die
 * categories()-Methode ergänzen — der Rest bleibt wie er ist.
 */
class Organisation extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'type',
        'name',
        'zvr_number',
        'email',
        'password',
        'description',
        'logo_path',
        'street',
        'zip',
        'city',
        'phone',
        'website',
        'representative',
        'contact_person',
        'newsletter_optin',
        'access_code',
        'is_registered',
        'is_approved',
        'is_active',
        'approved_at',
        'approved_by',
    ];

    protected $hidden = [
        'password',
    ];

    protected $casts = [
        'newsletter_optin' => 'boolean',
        'is_registered' => 'boolean',
        'is_approved' => 'boolean',
        'is_active' => 'boolean',
        'approved_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::creating(function (Organisation $organisation) {
            if ($organisation->password && ! str_starts_with($organisation->password, '$2y$')) {
                $organisation->password = Hash::make($organisation->password);
            }
        });
    }

    // Ergänzung für die Vereinssuche/-filterung:
    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class, 'organisation_category');
    }
}
