<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Organisation;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $vereine = $this->vereineQuery()->limit(8)->get()->map(fn ($o) => $this->mapVerein($o));

        // TODO: ersetzen durch echte Kategorie::pluck aus der DB, sobald Kategorien
        // im Filament-Backend final gepflegt sind. Aktuell statische Liste für die
        // Chip-Labels; die Filterung selbst (siehe vereineSuche()) nutzt bereits die
        // echte categories-Tabelle über den Slug.
        $kategorien = Category::orderBy('sort_order')->pluck('name', 'slug');
        if ($kategorien->isEmpty()) {
            $kategorien = collect([
                'feuerwehren' => 'Feuerwehren', 'rettungsdienste' => 'Rettungsdienste',
                'soziales-integration' => 'Soziales & Integration', 'sport' => 'Sport',
                'natur-umwelt' => 'Natur & Umwelt', 'kultur' => 'Kultur',
                'bildung-technik' => 'Bildung & Technik',
            ]);
        }

        // TODO: ersetzen durch echte Aggregation, z. B.
        // 'vereine' => Organisation::where('is_approved', true)->count().'+',
        $aktionen = collect([
            ['typ' => 'Aktion', 'titel' => 'Stammtisch für pflegende Angehörige', 'veranstalter' => 'Team Pflegenahversorgung', 'ort' => '9161 Maria Rain', 'zeit' => '14:00 Uhr', 'bild' => asset('img/4.avif'), 'bild_alt' => 'Gemeinschaftliche Unterstützung und Austausch'],
            ['typ' => 'Vortrag', 'titel' => 'Schlaganfall — was tun? Vortrag', 'veranstalter' => 'Ergotherapeutin Nicole Daumtschnig', 'ort' => '9161 Maria Rain', 'zeit' => '13:30 Uhr', 'bild' => asset('img/3.avif'), 'bild_alt' => 'Vortrag und Gesundheitsinformation'],
            ['typ' => 'Bewegung', 'titel' => 'Lauftraining Bewegungstreff', 'veranstalter' => 'UNION LFL Köstenberg', 'ort' => '9231 Velden am Wörther See', 'zeit' => '18:00 Uhr', 'bild' => asset('img/1.avif'), 'bild_alt' => 'Lauftraining in der Gruppe'],
        ]);

        $benefits = collect([
            ['partner' => 'RUTAR', 'beschreibung' => '10 % Exklusiv-Rabatt auf fast alles.', 'code' => 'mit Code: FWZ10'],
            ['partner' => 'FEICHTINGER', 'beschreibung' => '10 % auf ausgewählte Uhren und 20 % auf Schmuck & Eheringe.', 'code' => 'mit Code: FWZSPORT10'],
            ['partner' => 'ARBÖ', 'beschreibung' => '€ 25,– Gutschein auf verschiedene Dienstleistungen und Clubleistungen.', 'code' => 'Mitgliedervorteil'],
        ]);

        $testimonials = [
            ['zitat' => 'Beim Roten Kreuz finde ich Sinn und Gemeinschaft. Jeder Einsatz macht einen Unterschied.', 'person' => 'Maria L.', 'rolle' => 'ÖRK Kärnten'],
            ['zitat' => 'Die Bergrettung ist mehr als ein Hobby — sie ist Verantwortung, Teamgeist und Dankbarkeit.', 'person' => 'Thomas R.', 'rolle' => 'Bergrettung Kärnten'],
            ['zitat' => 'Im Verein begleiten wir Kinder beim Aufwachsen und schaffen Chancen für alle.', 'person' => 'Sophie K.', 'rolle' => 'Naturfreunde Kärnten'],
        ];

        $stats = [
            'vereine' => Organisation::where('is_approved', true)->where('is_active', true)->count().'+',
            'freiwillige' => '1.2k',
            'stunden' => '15k',
            'engagementFelder' => (string) max($kategorien->count(), 1),
        ];

        return view('home', compact('vereine', 'kategorien', 'aktionen', 'benefits', 'testimonials', 'stats'));
    }

    /**
     * JSON-Endpunkt für die Live-Suche/Autocomplete im Vereinsverzeichnis.
     * GET /vereine/suche?q=...&kategorie=<slug>
     */
    public function vereineSuche(Request $request)
    {
        $query = $this->vereineQuery();

        if ($request->filled('q')) {
            $q = $request->string('q');
            $query->where(function ($w) use ($q) {
                $w->where('name', 'like', "%{$q}%")
                  ->orWhere('city', 'like', "%{$q}%");
            });
        }

        if ($request->filled('kategorie') && $request->input('kategorie') !== 'alle') {
            $slug = $request->string('kategorie');
            $query->whereHas('categories', fn ($c) => $c->where('categories.slug', $slug));
        }

        $vereine = $query->limit(24)->get()->map(fn ($o) => $this->mapVerein($o));

        return response()->json(['results' => $vereine]);
    }

    private function vereineQuery()
    {
        return Organisation::query()
            ->where('is_approved', true)
            ->where('is_active', true)
            ->orderBy('name');
    }

    private function mapVerein(Organisation $organisation): array
    {
        return [
            'name' => $organisation->name,
            'ort' => $organisation->city,
            'kuerzel' => $this->kuerzel($organisation->name),
            'logo' => $organisation->logo_path
                ? asset('storage/'.$organisation->logo_path)
                : null,
        ];
    }

    private function kuerzel(string $name): string
    {
        $stopwords = ['und', 'der', 'die', 'das', 'von', 'in', 'am', 'im', 'für', 'e.v.'];
        $letters = collect(explode(' ', $name))
            ->reject(fn ($w) => in_array(mb_strtolower($w), $stopwords, true) || $w === '')
            ->take(4)
            ->map(fn ($w) => mb_strtoupper(mb_substr($w, 0, 1)))
            ->implode('');

        return $letters !== '' ? $letters : mb_strtoupper(mb_substr($name, 0, 3));
    }
}
