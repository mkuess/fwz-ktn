<?php

/**
 * In routes/web.php einfügen — vor einem eventuell vorhandenen
 * Fallback/Catch-all. /verwaltung (Filament) bleibt unberührt.
 */

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::view('/impressum', 'impressum')->name('impressum');
Route::view('/datenschutz', 'datenschutz')->name('datenschutz');
Route::view('/barrierefreiheit', 'barrierefreiheit')->name('barrierefreiheit');
Route::view('/in-arbeit', 'in-arbeit')->name('in-arbeit');
