/**
 * main.js – allgemeine UI-Logik (setzt KEINE Cookies, lädt KEINE Dritt-Dienste).
 */
(function () {
  "use strict";

  // Mobiles Menü
  var header = document.querySelector(".header");
  var toggle = document.querySelector(".nav-toggle");
  if (toggle && header) {
    toggle.addEventListener("click", function () {
      var isOpen = header.getAttribute("data-open") === "true";
      header.setAttribute("data-open", String(!isOpen));
      toggle.setAttribute("aria-expanded", String(!isOpen));
    });
  }

  // Filter-Chips im Vereinsverzeichnis (rein clientseitige UI, keine Datenverarbeitung)
  var chips = document.querySelectorAll(".chip");
  chips.forEach(function (chip) {
    chip.addEventListener("click", function () {
      chips.forEach(function (c) { c.setAttribute("aria-pressed", "false"); });
      chip.setAttribute("aria-pressed", "true");
    });
    chip.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        chip.click();
      }
    });
  });

  // Aktuelles Jahr im Footer
  var yearEl = document.getElementById("current-year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
})();
