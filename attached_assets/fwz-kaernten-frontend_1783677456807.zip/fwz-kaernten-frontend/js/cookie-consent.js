/**
 * cookie-consent.js
 * -----------------------------------------------------------------------
 * Barrierefreies, DSGVO- und TKG-konformes Cookie-/Consent-Management.
 *
 * Prinzipien (Stand der aktuellen Rechtslage, DSGVO Art. 6/7, ePrivacy /
 * österr. TKG §165 Abs. 3, Schrems/Planet49-Rechtsprechung):
 *  - Es werden VOR einer Einwilligung ausschließlich technisch notwendige
 *    Cookies/Skripte geladen (hier: keine).
 *  - Statistik- und Marketing-Skripte werden nur aktiviert, wenn die
 *    jeweilige Kategorie aktiv zugestimmt wurde (Opt-in, kein
 *    voreingestelltes Häkchen).
 *  - "Alle ablehnen" ist genauso leicht erreichbar wie "Alle akzeptieren"
 *    (gleichwertige Button-Gestaltung, keine Dark Patterns).
 *  - Die Einwilligung ist jederzeit über den Footer-Link
 *    "Cookie-Einstellungen" widerrufbar/änderbar.
 *  - Die Entscheidung wird lokal (localStorage) mit Zeitstempel und
 *    Versionsnummer gespeichert und bei Änderung der Kategorien/Version
 *    erneut abgefragt.
 *
 * Verwendung für künftige Dritt-Skripte (z.B. Statistik-Tool):
 *   <script type="text/plain" data-consent="statistics" data-src="…"></script>
 * Wird erst nach Zustimmung zur Kategorie "statistics" in ein echtes
 * <script src="…"> umgewandelt und ausgeführt.
 */
(function () {
  "use strict";

  var CONSENT_VERSION = "1.0";
  var STORAGE_KEY = "fwz_cookie_consent";

  var CATEGORIES = {
    necessary: {
      label: "Technisch notwendig",
      description:
        "Erforderlich, damit die Website grundlegend funktioniert (z. B. Navigation, Sicherheit, Speicherung Ihrer Cookie-Einstellung). Kann nicht deaktiviert werden.",
      required: true,
    },
    statistics: {
      label: "Statistik",
      description:
        "Hilft uns zu verstehen, wie die Website genutzt wird (z. B. anonymisierte Reichweitenmessung), um sie zu verbessern. Wird nur mit Ihrer Zustimmung aktiv.",
      required: false,
    },
    marketing: {
      label: "Marketing",
      description:
        "Wird für Inhalte Dritter (z. B. eingebettete Social-Media- oder Videoinhalte) verwendet und ist derzeit standardmäßig nicht aktiv.",
      required: false,
    },
  };

  function readConsent() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (parsed.version !== CONSENT_VERSION) return null;
      return parsed;
    } catch (e) {
      return null;
    }
  }

  function writeConsent(choices) {
    var payload = {
      version: CONSENT_VERSION,
      timestamp: new Date().toISOString(),
      necessary: true,
      statistics: !!choices.statistics,
      marketing: !!choices.marketing,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) {
      /* localStorage evtl. nicht verfügbar (privater Modus etc.) */
    }
    applyConsent(payload);
    document.dispatchEvent(new CustomEvent("fwzconsentchange", { detail: payload }));
    return payload;
  }

  function activateGatedScripts(payload) {
    document
      .querySelectorAll('script[type="text/plain"][data-consent]')
      .forEach(function (tpl) {
        var cat = tpl.getAttribute("data-consent");
        if (payload[cat] && !tpl.dataset.activated) {
          var real = document.createElement("script");
          Array.from(tpl.attributes).forEach(function (attr) {
            if (attr.name !== "type") real.setAttribute(attr.name, attr.value);
          });
          if (tpl.getAttribute("data-src")) {
            real.src = tpl.getAttribute("data-src");
          } else {
            real.textContent = tpl.textContent;
          }
          tpl.dataset.activated = "true";
          tpl.replaceWith(real);
        }
      });
  }

  function applyConsent(payload) {
    activateGatedScripts(payload);
  }

  /* ---------------------------------------------------------------- UI */

  function buildBanner() {
    var el = document.createElement("div");
    el.className = "cookie-banner";
    el.setAttribute("role", "region");
    el.setAttribute("aria-label", "Cookie-Hinweis");
    el.hidden = true;
    el.innerHTML =
      '<div class="cookie-banner__inner">' +
      '<p class="cookie-banner__text">' +
      "Wir verwenden auf freiwilligenzentrum-kaernten.at ausschließlich technisch notwendige Cookies. " +
      "Optionale Statistik-Cookies setzen wir nur mit Ihrer ausdrücklichen Zustimmung ein. " +
      'Details finden Sie in unserer <a href="datenschutz.html">Datenschutzerklärung</a>.' +
      "</p>" +
      '<div class="cookie-banner__actions">' +
      '<button type="button" class="btn dark" data-action="accept-all">Alle akzeptieren</button>' +
      '<button type="button" class="btn ghost" data-action="reject-all">Nur notwendige</button>' +
      '<button type="button" class="btn light" style="color:var(--ink);border-color:var(--line)" data-action="open-settings">Einstellungen</button>' +
      "</div></div>";
    document.body.appendChild(el);
    return el;
  }

  function buildSettingsDialog() {
    var wrap = document.createElement("div");
    wrap.className = "cookie-settings";
    wrap.hidden = true;

    var catsHtml = Object.keys(CATEGORIES)
      .map(function (key) {
        var c = CATEGORIES[key];
        var checkedAttr = key === "necessary" ? "checked disabled" : "";
        return (
          '<div class="cookie-cat">' +
          '<div class="cookie-cat__head">' +
          "<strong>" + c.label + "</strong>" +
          '<label class="switch">' +
          '<span class="sr-only">' + c.label + " aktivieren</span>" +
          '<input type="checkbox" data-cat="' + key + '" ' + checkedAttr + ">" +
          "</label></div>" +
          "<p>" + c.description + "</p>" +
          "</div>"
        );
      })
      .join("");

    wrap.innerHTML =
      '<div class="cookie-settings__panel" role="dialog" aria-modal="true" aria-labelledby="cookie-settings-title">' +
      '<h2 id="cookie-settings-title">Cookie-Einstellungen</h2>' +
      "<p>Legen Sie fest, welche Kategorien von Cookies wir auf dieser Website verwenden dürfen. Sie können Ihre Auswahl jederzeit über den Link „Cookie-Einstellungen“ im Seitenfuß ändern.</p>" +
      catsHtml +
      '<div class="cookie-settings__actions">' +
      '<button type="button" class="btn ghost" data-action="reject-all">Nur notwendige</button>' +
      '<button type="button" class="btn dark" data-action="save-settings">Auswahl speichern</button>' +
      '<button type="button" class="btn primary" data-action="accept-all">Alle akzeptieren</button>' +
      "</div></div>";
    document.body.appendChild(wrap);
    return wrap;
  }

  function trapFocus(container) {
    var focusable = container.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (!focusable.length) return;
    var first = focusable[0];
    var last = focusable[focusable.length - 1];
    container.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        closeSettings();
      }
      if (e.key !== "Tab") return;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    });
  }

  var bannerEl, settingsEl, lastFocused;

  function showBanner() {
    if (!bannerEl) bannerEl = buildBanner();
    bannerEl.hidden = false;
  }
  function hideBanner() {
    if (bannerEl) bannerEl.hidden = true;
  }

  function openSettings() {
    lastFocused = document.activeElement;
    if (!settingsEl) settingsEl = buildSettingsDialog();
    var current = readConsent();
    settingsEl.querySelectorAll("input[data-cat]").forEach(function (input) {
      var cat = input.getAttribute("data-cat");
      if (cat !== "necessary") {
        input.checked = current ? !!current[cat] : false;
      }
    });
    settingsEl.hidden = false;
    trapFocus(settingsEl);
    var firstFocusable = settingsEl.querySelector('input[data-cat="statistics"], button');
    if (firstFocusable) firstFocusable.focus();
  }
  function closeSettings() {
    if (settingsEl) {
      settingsEl.hidden = true;
      if (lastFocused) lastFocused.focus();
    }
  }

  document.addEventListener("click", function (e) {
    var actionEl = e.target.closest("[data-action]");
    if (!actionEl) return;
    var action = actionEl.getAttribute("data-action");

    if (action === "accept-all") {
      writeConsent({ statistics: true, marketing: true });
      hideBanner();
      closeSettings();
    }
    if (action === "reject-all") {
      writeConsent({ statistics: false, marketing: false });
      hideBanner();
      closeSettings();
    }
    if (action === "save-settings") {
      var stats = settingsEl.querySelector('input[data-cat="statistics"]').checked;
      var mkt = settingsEl.querySelector('input[data-cat="marketing"]').checked;
      writeConsent({ statistics: stats, marketing: mkt });
      hideBanner();
      closeSettings();
    }
    if (action === "open-settings") {
      openSettings();
    }
  });

  // Öffentlicher, dokumentierter API-Zugang (z.B. für Footer-Link "Cookie-Einstellungen")
  window.fwzConsent = {
    get: readConsent,
    openSettings: openSettings,
    categories: CATEGORIES,
  };

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll('[data-action="open-settings"]').forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        openSettings();
      });
    });

    var existing = readConsent();
    if (existing) {
      applyConsent(existing);
    } else {
      showBanner();
    }
  });
})();
