// Minimaler statischer Webserver für Replit.
// Liefert alle Dateien aus diesem Ordner aus (index.html, css/, js/, img/, Rechtsseiten).
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(
  express.static(__dirname, {
    extensions: ["html"],
    setHeaders: (res, filePath) => {
      // Grundlegende Sicherheits-Header (ersetzt kein vollständiges Security-Review)
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("X-Frame-Options", "DENY");
      res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
      if (filePath.endsWith(".html")) {
        res.setHeader("Cache-Control", "no-cache");
      } else {
        res.setHeader("Cache-Control", "public, max-age=3600");
      }
    },
  })
);

app.get("*", (req, res) => {
  res.status(404).sendFile(path.join(__dirname, "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`FWZ Kärnten Frontend läuft auf Port ${PORT}`);
});
