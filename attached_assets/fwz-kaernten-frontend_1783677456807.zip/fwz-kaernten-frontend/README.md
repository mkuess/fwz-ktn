# Freiwilligenzentrum Kärnten – Frontend

Statisches, barrierefreies Frontend für **freiwilligenzentrum-kaernten.at**, umgesetzt aus der gelieferten
Design-Vorlage. Ausgeliefert über einen minimalen Express-Server, damit es auf Replit direkt lauffähig ist.
Backend/APIs (Registrierung, Vereinssuche, Login etc.) wurden bewusst **nicht** hier eingebaut – Anbindung an
das in eurem anderen Chat gebaute Backend erfolgt über die markierten Stellen (siehe „Backend-Anbindung“ unten).

## 1. Struktur

```
index.html              Startseite
impressum.html          Impressum (§ 5 ECG / § 25 MedienG)
datenschutz.html        Datenschutzerklärung (Art. 13/14 DSGVO)
barrierefreiheit.html   Erklärung zur Barrierefreiheit (WZG / EU 2016/2102)
in-arbeit.html          Platzhalter für noch nicht angebundene Funktionen
css/style.css           Gesamtes Styling (Design-Tokens der Vorlage + A11y-Ergänzungen)
js/main.js              UI-Logik ohne Cookies/Tracking (Menü, Filter-Chips)
js/cookie-consent.js    Cookie-/Einwilligungsmanagement (Opt-in, granular, widerrufbar)
img/fwz-logo.svg        Original-Logo (von euch geliefert)
img/placeholder-*.svg   Austauschbare Platzhalterbilder
server.js, package.json Node/Express-Server für Replit
.replit                 Replit-Startkonfiguration
```

## 2. Deployment auf Replit

1. Neues Repl anlegen → Vorlage **„Node.js“** wählen (oder „Import from GitHub“, falls ihr das Projekt
   zuerst in ein Git-Repo legt).
2. Alle Dateien dieses Ordners in das Repl hochladen (Struktur beibehalten).
3. Replit erkennt `package.json`/`.replit` automatisch. Falls nicht automatisch gestartet:
   im Shell-Tab `npm install` ausführen, danach **Run** klicken (führt `npm start` → `node server.js` aus).
4. Die Website ist danach unter der von Replit vergebenen `*.repl.co`-URL bzw. nach „Deploy“ unter eurer
   eigenen Domain erreichbar.
5. Eigene Domain (`freiwilligenzentrum-kaernten.at`) unter *Deployments → Custom Domain* verbinden und
   passenden DNS-CNAME/A-Record setzen.

**Alternative ohne Node:** Da die Seite rein statisch ist, kann sie ebenso auf jedem anderen Static-Hosting
(Netlify, Vercel, GitHub Pages, Land-Kärnten-eigenes Hosting) deployt werden – dann ist `server.js` nicht
nötig, es reicht, den Ordnerinhalt hochzuladen.

## 3. Backend-Anbindung (aus eurem anderen Chat)

Aktuell sind folgende Stellen **funktionale Platzhalter** und müssen an eure API angebunden werden:

| Stelle | Datei/Zeile | Was zu tun ist |
|---|---|---|
| Vereinssuche | `index.html`, `<form class="searchbar">` | `action`/`method` durch echten API-Call ersetzen (z. B. `fetch()` in `js/main.js`, Ergebnisse dynamisch rendern) |
| Verein registrieren | Buttons „Jetzt Verein registrieren“ | Auf echtes Registrierungsformular/-flow umbiegen (aktuell `in-arbeit.html`) |
| Alle Aktionen / Alle Benefits | jeweilige Buttons | Auf dynamische Listing-Seiten umbiegen, die Daten vom Backend laden |
| Statistik-/Analyse-Tool | `js/cookie-consent.js` | Neues Skript **nicht direkt** einbinden, sondern als `<script type="text/plain" data-consent="statistics" data-src="…">` — wird automatisch erst nach Einwilligung aktiviert (siehe Kommentar im Code) |

## 4. Barrierefreiheit – was bereits umgesetzt ist

- Semantisches HTML5 (`header`, `nav`, `main`, `section`, `footer`, korrekte Überschriftenhierarchie h1–h3)
- `lang="de"` auf allen Seiten
- „Zum Hauptinhalt springen“-Skip-Link auf jeder Seite
- Sichtbare, kontrastreiche Fokus-Zustände (`:focus-visible`) für Tastaturnutzung
- Alle Bilder mit Alternativtexten (Icons `aria-hidden`, informative Bilder mit sprechendem `alt`)
- Formularfelder mit zugeordneten (auch visuell versteckten) Labels statt reinem `placeholder`
- Buttons/Links mit Mindestgröße 44×44px für Touch-Bedienung
- `prefers-reduced-motion` wird respektiert
- Farbkontraste der Kernfarben wurden auf AA-Tauglichkeit angepasst (z. B. `--eyebrow`-Gelb abgedunkelt für
  Text auf Weiß)
- Cookie-Banner und -Dialog sind per Tastatur bedienbar, der Einstellungsdialog nutzt einen Fokus-Trap

**Vor dem Livegang unbedingt noch nötig** (siehe auch `barrierefreiheit.html`):
- Manuelle Prüfung mit Screenreader (NVDA/VoiceOver) und reiner Tastaturbedienung
- Automatisierter Check (z. B. axe DevTools, Lighthouse, WAVE)
- Farbkontrast-Check der finalen Echtbilder (sobald Platzhalter ersetzt sind)
- Ausfüllen des Konformitätsstatus in `barrierefreiheit.html`

## 5. Cookies & Datenschutz – was bereits umgesetzt ist

- Vor jeder Einwilligung werden **ausschließlich technisch notwendige** Funktionen geladen; es sind aktuell
  keinerlei Tracking-/Statistik-/Marketing-Skripte im Code enthalten.
- Cookie-Banner mit **gleichwertigen** Buttons „Alle akzeptieren“ / „Nur notwendige“ / „Einstellungen“ (kein
  Dark Pattern, kein vorangehakter Zustand für optionale Kategorien).
- Granulare Einstellungen (Kategorien: notwendig / Statistik / Marketing), jederzeit über den Footer-Link
  **„Cookie-Einstellungen“** änderbar (Widerruf so leicht wie Erteilung, Art. 7 Abs. 3 DSGVO).
- Entscheidung wird versioniert mit Zeitstempel lokal gespeichert; ändert ihr die Kategorien inhaltlich,
  einfach `CONSENT_VERSION` in `js/cookie-consent.js` hochzählen – Nutzer:innen werden dann automatisch
  erneut gefragt.
- `datenschutz.html` ist als vollständiges DSGVO-Gerüst (Art. 13/14) vorbereitet.

**Vor dem Livegang unbedingt noch nötig:**
- Alle mit `[…]` markierten Platzhalter in `impressum.html`, `datenschutz.html`, `barrierefreiheit.html`
  durch die echten Rechts-/Kontaktdaten ersetzen (Vereinsdaten, ZVR-Zahl, Hosting-Anbieter, Aufbewahrungsfristen …).
- Sobald ein Statistik-Tool (z. B. eine DSGVO-konforme, IP-anonymisierte Lösung) eingebunden wird: Cookie-Tabelle
  in `datenschutz.html` konkretisieren (Name, genaue Speicherdauer, Anbieter, ggf. Drittlandtransfer).
- Prüfen, ob eine formelle Auftragsverarbeitungsvereinbarung (Art. 28 DSGVO) mit dem Hosting-/IT-Anbieter
  vorliegt.
- Bei Einsatz von Formularen mit sensiblen Daten: TLS/HTTPS ist zwingend (auf Replit/den meisten Hostern
  standardmäßig aktiv – vor Go-Live verifizieren).

## 6. Rechtlicher Gesamt-Check (kurz)

| Anforderung | Rechtsgrundlage | Status in diesem Projekt |
|---|---|---|
| Impressum | § 5 ECG, § 25 MedienG | Gerüst fertig, Rechtsdaten einzutragen |
| Datenschutzerklärung | Art. 13/14 DSGVO | Gerüst fertig, Details je nach Backend zu ergänzen |
| Cookie-Einwilligung (Opt-in) | § 165 Abs. 3 TKG 2021, Art. 6 DSGVO | Umgesetzt |
| Widerspruchs-/Widerrufsmöglichkeit | Art. 7 Abs. 3, Art. 21 DSGVO | Umgesetzt (Footer-Link jederzeit) |
| Barrierefreiheit öffentlicher Stellen | WZG / EU-Richtlinie 2016/2102 | Technisch weitgehend umgesetzt, Prüfbericht/Konformitätsstatus offen |
| Beschwerderecht Datenschutz | Art. 77 DSGVO | In `datenschutz.html` verlinkt (DSB Wien) |
| Schlichtungsverfahren Barrierefreiheit | WZG | In `barrierefreiheit.html` verlinkt (Sozialministeriumservice) |

> **Wichtiger Hinweis:** Dieses Projekt liefert eine technisch und inhaltlich vollständige, aber generische
> Rechts-Grundstruktur. Es ersetzt keine individuelle Rechtsberatung. Da es sich um eine Landesseite handelt,
> empfehlen wir vor dem Go-Live eine Kurzprüfung durch die zuständige Rechtsabteilung des Landes Kärnten
> bzw. eine:n auf IT-/Datenschutzrecht spezialisierte:n Anwält:in – insbesondere zur korrekten Bezeichnung
> des Rechtsträgers/Medieninhabers und zur endgültigen Konformitätsstufe der Barrierefreiheitserklärung.
