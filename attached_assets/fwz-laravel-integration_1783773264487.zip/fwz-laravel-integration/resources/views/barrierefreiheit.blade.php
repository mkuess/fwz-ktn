@extends('layouts.app')

@section('title', 'Erklärung zur Barrierefreiheit – Freiwilligenzentrum Kärnten')
@section('meta_description', 'Erklärung zur Barrierefreiheit des Freiwilligenzentrums Kärnten gemäß Web-Zugänglichkeits-Gesetz (WZG) und EU-Richtlinie 2016/2102.')

@section('hero')
<div class="page-hero">
  <div class="container">
    <h1 class="h2">Erklärung zur Barrierefreiheit</h1>
    <p>Diese Erklärung gilt für die Website freiwilligenzentrum-kaernten.at und wurde in Anlehnung an das
    österreichische Web-Zugänglichkeits-Gesetz (WZG) sowie die EU-Richtlinie 2016/2102 erstellt.</p>
  </div>
</div>
@endsection

@section('content')
<div class="container">
  <div class="box">

    <h2>1. Einordnung als öffentliche Stelle</h2>
    <p>
      Das Freiwilligenzentrum Kärnten ist die offizielle Anlaufstelle des Landes Kärnten für ehrenamtliches
      Engagement. Als Website mit Bezug zu einer öffentlichen Stelle unterliegt dieses Angebot den
      Anforderungen des Web-Zugänglichkeits-Gesetzes (WZG), das die EU-Richtlinie (EU) 2016/2102 in
      österreichisches Recht umsetzt, sowie den technischen Standards der EN 301 549 auf Basis der
      Web Content Accessibility Guidelines (WCAG) 2.1, Konformitätsstufe AA.
    </p>

    <h2>2. Stand der Vereinbarkeit</h2>
    <p>
      Diese Website wurde nach den Grundsätzen der Barrierefreiheit gestaltet: semantische Struktur,
      Tastaturbedienbarkeit, sichtbare Fokuszustände, Alternativtexte für Bilder, ausreichende
      Kontrastverhältnisse, Sprachauszeichnung (<code>lang="de"</code>) und ein „Sprung zum Inhalt“-Link.
    </p>
    <p>
      Der tatsächliche Konformitätsstatus kann erst nach einer vollständigen manuellen und technischen
      Prüfung (inkl. Test mit Screenreadern wie NVDA/JAWS/VoiceOver und Tastatur-Only-Navigation)
      abschließend festgestellt werden. Aktueller Status:
    </p>
    <p>
      <strong><span class="placeholder-field">[Status wählen: „vollständig konform“ / „teilweise konform“ / „nicht konform“ – nach durchgeführter Prüfung eintragen]</span></strong>
    </p>

    <h3>Bekannte, noch zu prüfende bzw. nicht barrierefreie Inhalte</h3>
    <ul>
      <li>Platzhalterbilder (SVG) enthalten derzeit generische Alternativtexte und werden beim Austausch
        durch redaktionelle Fotos mit aussagekräftigen, individuellen Alternativtexten versehen.</li>
      <li>Dynamisch aus dem Backend geladene Inhalte (Vereine, Aktionen, Benefits) müssen bei jeder
        redaktionellen Eingabe im Filament-Backend mit sprechenden Bildbeschreibungen (Alt-Texten) gepflegt
        werden – das Frontend gibt vorhandene Alt-Texte 1:1 aus, kann sie aber nicht automatisch erzeugen.</li>
      <li>Eingebettete Inhalte Dritter (z. B. Kartendienste, Social-Media-Einbettungen), sofern künftig
        hinzugefügt, werden erst nach Prüfung ihrer Barrierefreiheit bzw. mit entsprechendem Hinweis
        eingebunden.</li>
      <li><span class="placeholder-field">[weitere bekannte Ausnahmen ergänzen]</span></li>
    </ul>
    <p>
      Unverhältnismäßige Belastung im Sinne des WZG wird für die genannten Punkte derzeit
      <span class="placeholder-field">[nicht geltend gemacht / geltend gemacht mit folgender Begründung: …]</span>.
    </p>

    <h2>3. Erstellung dieser Erklärung</h2>
    <p>
      Diese Erklärung wurde am <span class="placeholder-field">[Datum]</span> erstellt und zuletzt am
      <span class="placeholder-field">[Datum]</span> überprüft. Grundlage der Bewertung:
      <span class="placeholder-field">[Selbstbewertung durch den Betreiber / externe Prüfung durch … – Zutreffendes eintragen]</span>.
    </p>

    <h2>4. Feedback und Kontaktangaben</h2>
    <p>
      Stoßen Sie beim Nutzen dieser Website auf Barrieren, oder benötigen Sie Informationen dieser Website in
      einer alternativen, barrierefreien Form, kontaktieren Sie uns bitte:
    </p>
    <ul>
      <li>E-Mail: <a href="mailto:barrierefreiheit@freiwilligenzentrum-kaernten.at">barrierefreiheit@freiwilligenzentrum-kaernten.at</a></li>
      <li>Telefon: <span class="placeholder-field">[Telefonnummer]</span></li>
      <li>Post: Freiwilligenzentrum Kärnten, Bahnhofplatz 5/1, 9020 Klagenfurt am Wörthersee</li>
    </ul>
    <p>
      Wir bemühen uns, Ihre Meldung innerhalb von <span class="placeholder-field">[z. B. 14 Werktagen]</span>
      zu beantworten bzw. die gewünschte Information in einer zugänglichen Alternative bereitzustellen.
    </p>

    <h2>5. Durchsetzungsverfahren (Schlichtung)</h2>
    <p>
      Sollten Sie mit der Antwort auf Ihre Meldung oder Anfrage nicht zufrieden sein, können Sie sich im
      Rahmen eines Schlichtungsverfahrens an das Sozialministeriumservice wenden, das für die Überwachung
      der Einhaltung des Web-Zugänglichkeits-Gesetzes zuständig ist:
    </p>
    <p>
      Sozialministeriumservice – Schlichtungsstelle<br>
      <a href="https://www.sozialministeriumservice.at" target="_blank" rel="noopener noreferrer">www.sozialministeriumservice.at</a>
    </p>
    <p>
      Alternativ steht Ihnen die Behindertenanwaltschaft als beratende Stelle offen:
      <a href="https://www.behindertenanwalt.gv.at" target="_blank" rel="noopener noreferrer">www.behindertenanwalt.gv.at</a>.
    </p>

    <div class="note-box">
      <strong>Hinweis zur Fertigstellung</strong>
      Diese Erklärung ist ein rechtlich vollständiges Gerüst nach den formalen Vorgaben des WZG. Für eine
      belastbare Konformitätsaussage ist vor Livegang eine tatsächliche Prüfung (automatisiert, z. B. mit
      axe-core/Lighthouse, sowie manuell mit Tastatur und Screenreader) durchzuführen und diese Seite mit den
      realen Ergebnissen, Prüfdaten und einer verbindlichen Konformitätsstufe zu vervollständigen.
    </div>

  </div>
</div>
@endsection
