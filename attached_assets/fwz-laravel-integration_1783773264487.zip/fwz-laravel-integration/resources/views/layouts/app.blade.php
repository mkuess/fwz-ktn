<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', 'Freiwilligenzentrum Kärnten')</title>
<meta name="description" content="@yield('meta_description', 'Das Freiwilligenzentrum Kärnten (FWZ) ist die zentrale Anlaufstelle des Landes Kärnten für ehrenamtliches Engagement.')">
<meta name="color-scheme" content="light">
<link rel="icon" href="{{ asset('img/fwz-logo.svg') }}" type="image/svg+xml">
<link rel="stylesheet" href="{{ asset('css/style.css') }}">
@stack('head')
</head>
<body>

<a class="skip-link" href="#main-content">Zum Hauptinhalt springen</a>

<header class="header {{ $pageHero ?? false ? 'header--page' : '' }}">
  <nav class="nav" aria-label="Hauptnavigation">
    <div class="nav-left">
      <a href="{{ route('home') }}" aria-label="Freiwilligenzentrum Kärnten – Startseite">
        <img class="logo" src="{{ asset('img/fwz-logo.svg') }}" alt="Freiwilligenzentrum Kärnten" width="168" height="78">
      </a>
      @unless($pageHero ?? false)
      <ul class="menu" id="mobile-menu">
        <li><a href="{{ route('home') }}#fwz">Was ist FWZ</a></li>
        <li><a href="{{ route('home') }}#willkommen">Herzlich willkommen</a></li>
        <li><a href="{{ route('home') }}#registrieren">Registrieren</a></li>
        <li><a href="{{ route('home') }}#vereine">Vereine</a></li>
        <li><a href="{{ route('home') }}#aktionen">Aktuelles</a></li>
      </ul>
      @endunless
    </div>
    <div class="nav-actions">
      @if($pageHero ?? false)
        <a class="btn primary" href="{{ route('home') }}">Zur Startseite</a>
      @else
        <a class="btn primary" href="{{ route('home') }}#aktionen">Ich möchte helfen <span class="arrow" aria-hidden="true">→</span></a>
        <a class="btn light" href="{{ route('home') }}#registrieren">Verein anmelden</a>
      @endif
    </div>
    @unless($pageHero ?? false)
    <button type="button" class="nav-toggle" aria-expanded="false" aria-controls="mobile-menu">
      Menü <span aria-hidden="true">☰</span>
    </button>
    @endunless
  </nav>
</header>

@yield('hero')

<main id="main-content" class="{{ ($pageHero ?? false) ? 'legal-content' : '' }}">
  @yield('content')
</main>

<footer class="footer">
  @hasSection('footer-grid')
    @yield('footer-grid')
  @endif
  <div class="container copyright">
    <span>© <span id="current-year">{{ date('Y') }}</span> Freiwilligenzentrum Kärnten</span>
    <span class="legal-links">
      <a href="{{ route('home') }}">Startseite</a>
      <a href="{{ route('impressum') }}">Impressum</a>
      <a href="{{ route('datenschutz') }}">Datenschutz</a>
      <a href="{{ route('barrierefreiheit') }}">Barrierefreiheit</a>
      <a href="#" data-action="open-settings">Cookie-Einstellungen</a>
    </span>
  </div>
</footer>

<script src="{{ asset('js/main.js') }}" defer></script>
<script src="{{ asset('js/cookie-consent.js') }}" defer></script>
@stack('scripts')
</body>
</html>
