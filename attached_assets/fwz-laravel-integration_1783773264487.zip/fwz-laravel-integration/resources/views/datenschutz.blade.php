@extends('layouts.app')

@section('title', 'Datenschutzerklärung – Freiwilligenzentrum Kärnten')
@section('meta_description', 'Datenschutzerklärung des Freiwilligenzentrums Kärnten gemäß Art. 13/14 DSGVO – Verarbeitungszwecke, Cookies und Ihre Rechte.')

@section('hero')
<div class="page-hero">
  <div class="container">
    <h1 class="h2">Datenschutzerklärung</h1>
    <p>Informationen gemäß Art. 13 und Art. 14 der Datenschutz-Grundverordnung (DSGVO) sowie dem
    österreichischen Datenschutzgesetz (DSG).</p>
  </div>
</div>
@endsection

@section('content')
<div class="container">
  <div class="box">

    <div class="toc">
      <p>Inhalt dieser Erklärung</p>
      <ol>
        <li><a href="#verantwortlicher">Verantwortlicher &amp; Kontakt</a></li>
        <li><a href="#grundsaetze">Allgemeine Grundsätze der Datenverarbeitung</a></li>
        <li><a href="#hosting">Hosting &amp; Server-Logfiles</a></li>
        <li><a href="#cookies">Cookies &amp; Einwilligungsverwaltung</a></li>
        <li><a href="#registrierung">Vereinsregistrierung</a></li>
        <li><a href="#kontakt">Kontaktaufnahme (E-Mail, Telefon)</a></li>
        <li><a href="#empfaenger">Empfänger, Auftragsverarbeiter, Drittländer</a></li>
        <li><a href="#speicherdauer">Speicherdauer</a></li>
        <li><a href="#rechte">Ihre Rechte als betroffene Person</a></li>
        <li><a href="#beschwerde">Beschwerderecht</a></li>
        <li><a href="#aenderungen">Änderungen dieser Erklärung</a></li>
      </ol>
    </div>

    <h2 id="verantwortlicher">1. Verantwortlicher &amp; Kontakt</h2>
    <p>
      Verantwortlicher im Sinne der DSGVO für die Datenverarbeitung auf dieser Website ist:<br>
      <span class="placeholder-field">[Vollständiger Rechtsträger, Anschrift]</span><br>
      E-Mail: <a href="mailto:office@freiwilligenzentrum-kaernten.at">office@freiwilligenzentrum-kaernten.at</a><br>
      Telefon: <span class="placeholder-field">[Telefonnummer]</span>
    </p>
    <p>
      Datenschutzbeauftragte/r (sofern bestellt):
      <span class="placeholder-field">[Name/Kontakt des Datenschutzbeauftragten oder Vermerk „derzeit nicht bestellt, da gesetzlich nicht erforderlich“]</span>
    </p>

    <h2 id="grundsaetze">2. Allgemeine Grundsätze</h2>
    <p>
      Wir verarbeiten personenbezogene Daten unter Beachtung der Grundsätze der Rechtmäßigkeit,
      Zweckbindung, Datenminimierung, Richtigkeit, Speicherbegrenzung, Integrität, Vertraulichkeit und
      Rechenschaftspflicht (Art. 5 DSGVO). Eine automatisierte Entscheidungsfindung einschließlich Profiling
      im Sinne von Art. 22 DSGVO findet nicht statt.
    </p>

    <h2 id="hosting">3. Hosting &amp; Server-Logfiles</h2>
    <p>
      Beim Aufruf dieser Website erhebt unser Hosting-Anbieter automatisch technische Zugriffsdaten
      (sogenannte Server-Logfiles), die Ihr Browser übermittelt. Dazu zählen insbesondere:
    </p>
    <ul>
      <li>gekürzte/anonymisierte IP-Adresse</li>
      <li>Datum und Uhrzeit der Anfrage</li>
      <li>aufgerufene Seite/Datei und Referrer-URL</li>
      <li>Browsertyp, Betriebssystem, übertragene Datenmenge, HTTP-Statuscode</li>
    </ul>
    <p>
      Rechtsgrundlage ist unser berechtigtes Interesse (Art. 6 Abs. 1 lit. f DSGVO) an einem sicheren,
      funktionsfähigen und stabilen Betrieb der Website. Diese Daten werden nicht mit anderen Datenquellen
      zusammengeführt und in der Regel nach <span class="placeholder-field">[z. B. 7–14 Tagen]</span>
      automatisch gelöscht.
    </p>
    <p>
      Hosting-Anbieter: <span class="placeholder-field">[Name, Anschrift und ggf. Sitz des Hosting-Providers eintragen]</span>
    </p>

    <h2 id="cookies">4. Cookies &amp; Einwilligungsverwaltung</h2>
    <p>
      Diese Website verwendet Cookies und vergleichbare Technologien (z. B. Local Storage), um Ihre
      Cookie-Einstellung zu speichern. Nicht technisch notwendige Cookies (z. B. für Statistik oder
      Marketing) werden ausschließlich mit Ihrer vorherigen, ausdrücklichen Einwilligung gesetzt
      (§ 165 Abs. 3 TKG 2021 i. V. m. Art. 6 Abs. 1 lit. a DSGVO). Sie können Ihre Auswahl jederzeit über den
      Link „Cookie-Einstellungen“ im Seitenfuß ändern oder widerrufen.
    </p>
    <table>
      <thead>
        <tr><th scope="col">Kategorie</th><th scope="col">Zweck</th><th scope="col">Rechtsgrundlage</th><th scope="col">Speicherdauer</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>Technisch notwendig</td>
          <td>Speicherung Ihrer Cookie-Auswahl (lokal, kein Server-Tracking)</td>
          <td>Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse am Betrieb)</td>
          <td>12 Monate (lokal im Browser)</td>
        </tr>
        <tr>
          <td>Statistik</td>
          <td><span class="placeholder-field">[derzeit nicht aktiv – bei Einsatz eines Analyse-Tools hier ergänzen]</span></td>
          <td>Art. 6 Abs. 1 lit. a DSGVO (Einwilligung)</td>
          <td><span class="placeholder-field">[ergänzen]</span></td>
        </tr>
        <tr>
          <td>Marketing</td>
          <td>derzeit nicht im Einsatz</td>
          <td>Art. 6 Abs. 1 lit. a DSGVO (Einwilligung)</td>
          <td>—</td>
        </tr>
      </tbody>
    </table>
    <p>
      <a class="btn ghost" style="border:2px solid var(--line);" href="#" data-action="open-settings">Cookie-Einstellungen öffnen</a>
    </p>

    <h2 id="registrierung">5. Vereinsregistrierung</h2>
    <p>
      Wenn Sie Ihren Verein über das Formular „Verein registrieren“ anmelden, verarbeiten wir die von Ihnen
      eingegebenen Daten (u. a. Vereinsname, Tätigkeitsfeld, Ansprechperson, Kontaktdaten) zum Zweck der
      Prüfung, Freischaltung und Führung im Vereinsverzeichnis sowie zur Zusendung des Vereinscodes.
      Rechtsgrundlage ist die Erfüllung eines Vertrags bzw. vorvertraglicher Maßnahmen (Art. 6 Abs. 1 lit. b
      DSGVO). Die Angabe der als Pflichtfeld gekennzeichneten Daten ist für die Registrierung erforderlich;
      ohne diese Daten können wir Ihre Anfrage nicht bearbeiten.
    </p>

    <h2 id="kontakt">6. Kontaktaufnahme (E-Mail, Telefon)</h2>
    <p>
      Kontaktieren Sie uns per E-Mail oder Telefon, verarbeiten wir die dabei mitgeteilten Daten
      (u. a. Kontaktdaten, Inhalt der Nachricht) zur Bearbeitung Ihres Anliegens. Rechtsgrundlage ist je nach
      Anliegen Art. 6 Abs. 1 lit. b DSGVO (vertragliche/vorvertragliche Anfrage) oder Art. 6 Abs. 1 lit. f
      DSGVO (berechtigtes Interesse an der Beantwortung von Anfragen).
    </p>

    <h2 id="empfaenger">7. Empfänger, Auftragsverarbeiter, Drittländer</h2>
    <p>
      Ihre Daten werden nur an Empfänger weitergegeben, soweit dies zur Zweckerreichung erforderlich ist,
      etwa an:
    </p>
    <ul>
      <li>unseren Hosting-/IT-Dienstleister (Auftragsverarbeitung gemäß Art. 28 DSGVO): <span class="placeholder-field">[Name eintragen]</span></li>
      <li>ggf. eingebundene technische Dienstleister für Statistik, sofern eine Einwilligung vorliegt</li>
    </ul>
    <p>
      Eine Übermittlung in Drittländer außerhalb der EU/des EWR findet
      <span class="placeholder-field">[derzeit nicht statt / findet statt an … auf Grundlage von Standardvertragsklauseln gemäß Art. 46 DSGVO – Zutreffendes eintragen]</span>.
    </p>

    <h2 id="speicherdauer">8. Speicherdauer</h2>
    <p>
      Personenbezogene Daten werden nur so lange gespeichert, wie dies für die jeweiligen Zwecke erforderlich
      ist oder solange gesetzliche Aufbewahrungspflichten bestehen. Nach Zweckfortfall bzw. Ablauf
      gesetzlicher Fristen werden die Daten gelöscht oder anonymisiert.
    </p>

    <h2 id="rechte">9. Ihre Rechte als betroffene Person</h2>
    <p>Ihnen stehen nach Maßgabe der gesetzlichen Voraussetzungen folgende Rechte zu:</p>
    <ul>
      <li>Recht auf Auskunft (Art. 15 DSGVO)</li>
      <li>Recht auf Berichtigung (Art. 16 DSGVO)</li>
      <li>Recht auf Löschung (Art. 17 DSGVO)</li>
      <li>Recht auf Einschränkung der Verarbeitung (Art. 18 DSGVO)</li>
      <li>Recht auf Datenübertragbarkeit (Art. 20 DSGVO)</li>
      <li>Widerspruchsrecht gegen Verarbeitungen auf Grundlage berechtigter Interessen (Art. 21 DSGVO)</li>
      <li>Recht, eine erteilte Einwilligung jederzeit mit Wirkung für die Zukunft zu widerrufen (Art. 7 Abs. 3 DSGVO)</li>
    </ul>
    <p>
      Zur Ausübung dieser Rechte genügt eine formlose Mitteilung an
      <a href="mailto:office@freiwilligenzentrum-kaernten.at">office@freiwilligenzentrum-kaernten.at</a>.
    </p>

    <h2 id="beschwerde">10. Beschwerderecht bei der Aufsichtsbehörde</h2>
    <p>
      Sie haben unbeschadet anderweitiger verwaltungsrechtlicher oder gerichtlicher Rechtsbehelfe das Recht
      auf Beschwerde bei einer Datenschutz-Aufsichtsbehörde, insbesondere in Österreich bei der:
    </p>
    <p>
      Österreichische Datenschutzbehörde<br>
      Barichgasse 40–42, 1030 Wien<br>
      <a href="https://www.dsb.gv.at" target="_blank" rel="noopener noreferrer">www.dsb.gv.at</a>
    </p>

    <h2 id="aenderungen">11. Änderungen dieser Datenschutzerklärung</h2>
    <p>
      Wir passen diese Datenschutzerklärung an, sobald Änderungen der von uns durchgeführten
      Datenverarbeitung oder der Rechtslage dies erforderlich machen. Es gilt jeweils die auf dieser Seite
      veröffentlichte, aktuelle Fassung.
    </p>
    <p class="muted">Stand: <span class="placeholder-field">[Datum der letzten Aktualisierung eintragen]</span></p>

    <div class="note-box">
      <strong>Hinweis zur Fertigstellung</strong>
      Diese Erklärung deckt den aktuellen Funktionsumfang ab. Sobald das Filament-Backend produktiv Daten
      liefert (z. B. echte Formularverarbeitung für Registrierung, Benutzerkonten, Statistik-Tools,
      Newsletter), müssen die betroffenen Abschnitte ergänzt und ein Verzeichnis von
      Verarbeitungstätigkeiten (Art. 30 DSGVO) geführt werden.
    </div>

  </div>
</div>
@endsection
