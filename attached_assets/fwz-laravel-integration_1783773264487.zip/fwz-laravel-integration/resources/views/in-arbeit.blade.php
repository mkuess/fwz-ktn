@extends('layouts.app')

@section('title', 'In Vorbereitung – Freiwilligenzentrum Kärnten')

@section('hero')
<div class="page-hero">
  <div class="container">
    <h1 class="h2">Diese Funktion ist in Vorbereitung.</h1>
  </div>
</div>
@endsection

@section('content')
<div class="container">
  <div class="box" style="text-align:center; padding:70px 30px;">
    <p>
      Diese Funktion wird gerade an das Backend angebunden. Bis dahin erreichen Sie uns direkt unter
      <a href="mailto:office@freiwilligenzentrum-kaernten.at">office@freiwilligenzentrum-kaernten.at</a>.
    </p>
    <p style="margin-top:24px;"><a class="btn dark" href="{{ route('home') }}">Zurück zur Startseite</a></p>
  </div>
</div>
@endsection
