@extends('layouts.app')

@section('title', 'Impressum – Freiwilligenzentrum Kärnten')
@section('meta_description', 'Impressum und Offenlegung gemäß § 5 ECG und § 25 Mediengesetz des Freiwilligenzentrums Kärnten.')

@section('hero')
<div class="page-hero">
  <div class="container">
    <h1 class="h2">Impressum</h1>
    <p>Offenlegung gemäß § 5 E-Commerce-Gesetz (ECG) und § 25 Mediengesetz (MedienG).</p>
  </div>
</div>
@endsection

@section('content')
<div class="container">
  <div class="box">

    <h2>Diensteanbieter / Medieninhaber</h2>
    <p>
      <span class="placeholder-field">[Vollständiger Rechtsträger, z. B. „Freiwilligenzentrum Kärnten – Verein zur Förderung des Ehrenamtes“ bzw. zuständige Dienststelle des Amtes der Kärntner Landesregierung]</span><br>
      <span class="placeholder-field">[Straße, Hausnummer]</span><br>
      9020 Klagenfurt am Wörthersee, Österreich
    </p>

    <h3>Kontakt</h3>
    <ul>
      <li>Telefon: <span class="placeholder-field">[+43 463 …]</span></li>
      <li>E-Mail: <a href="mailto:office@freiwilligenzentrum-kaernten.at">office@freiwilligenzentrum-kaernten.at</a></li>
    </ul>

    <h3>Register- und Identifikationsdaten</h3>
    <table>
      <tbody>
        <tr><th scope="row">Vereinsregisterzahl (ZVR)</th><td><span class="placeholder-field">[ZVR-Zahl eintragen, falls Verein]</span></td></tr>
        <tr><th scope="row">Firmenbuchnummer / -gericht</th><td><span class="placeholder-field">[nur falls im Firmenbuch eingetragen]</span></td></tr>
        <tr><th scope="row">UID-Nummer</th><td><span class="placeholder-field">[nur falls umsatzsteuerpflichtig]</span></td></tr>
        <tr><th scope="row">Zuständige Aufsichtsbehörde</th><td><span class="placeholder-field">[z. B. Amt der Kärntner Landesregierung, falls einschlägig]</span></td></tr>
      </tbody>
    </table>

    <h3>Vertretungsbefugte Personen</h3>
    <p><span class="placeholder-field">[Name/Funktion der vertretungsbefugten Person(en), z. B. Obmann/Obfrau, Geschäftsführung]</span></p>

    <h2>Offenlegung gemäß § 25 Mediengesetz</h2>
    <h3>Grundlegende Richtung (Blattlinie)</h3>
    <p>
      Diese Website dient der Information über das ehrenamtliche Engagement in Kärnten, die Vernetzung von
      Freiwilligen und Vereinen sowie die Bewerbung von Aktionen, Veranstaltungen und Mitgliedervorteilen des
      Freiwilligenzentrums Kärnten. Eine parteipolitische Einflussnahme findet nicht statt.
    </p>

    <h2>EU-Streitschlichtung</h2>
    <p>
      Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit, abrufbar unter
      <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener noreferrer">ec.europa.eu/consumers/odr</a>.
      Wir sind zur Teilnahme an einem Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle
      <span class="placeholder-field">[nicht verpflichtet / bereit – Zutreffendes eintragen]</span>.
    </p>

    <h2>Haftung für Inhalte dieser Website</h2>
    <p>
      Wir entwickeln die Inhalte dieser Website mit größtmöglicher Sorgfalt. Für die Richtigkeit, Vollständigkeit
      und Aktualität der bereitgestellten Inhalte können wir jedoch keine Gewähr übernehmen. Als Diensteanbieter
      sind wir gemäß § 18 ECG nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu
      überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
    </p>

    <h2>Haftung für Links</h2>
    <p>
      Unsere Website enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben.
      Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten
      Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
    </p>

    <h2>Urheberrecht</h2>
    <p>
      Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem
      österreichischen Urheberrecht. Beiträge Dritter sind als solche gekennzeichnet. Die Vervielfältigung,
      Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der
      schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.
    </p>

    <h2>Bildnachweise</h2>
    <p>
      Bildrechte der auf dieser Website verwendeten Fotografien liegen, sofern nicht anders angegeben, beim
      Freiwilligenzentrum Kärnten bzw. bei den jeweils genannten Rechteinhabern.
    </p>

    <div class="note-box">
      <strong>Hinweis zur Fertigstellung</strong>
      Die mit <span class="placeholder-field">[…]</span> gekennzeichneten Felder sind vor der Veröffentlichung
      durch die tatsächlichen Rechts- und Registerdaten des Betreibers zu ersetzen. Ein unvollständiges Impressum
      stellt in Österreich einen Wettbewerbsverstoß (UWG) und einen Verstoß gegen § 5 ECG / § 25 MedienG dar und
      kann abgemahnt werden.
    </div>

  </div>
</div>
@endsection
