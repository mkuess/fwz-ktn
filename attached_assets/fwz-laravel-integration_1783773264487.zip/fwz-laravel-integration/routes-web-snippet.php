<?php

/**
 * ---------------------------------------------------------------------
 * Add these routes to routes/web.php (public frontend routes).
 * Keep Filament's /verwaltung panel untouched — it registers its own
 * routes via its Service Provider and is not affected by this file.
 *
 * IMPORTANT: If routes/web.php already contains a catch-all/fallback
 * route (e.g. Route::fallback(...) or a wildcard like Route::get('{any}', ...)),
 * make sure these routes are registered BEFORE that fallback.
 * ---------------------------------------------------------------------
 */

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::view('/impressum', 'impressum', ['pageHero' => true])->name('impressum');
Route::view('/datenschutz', 'datenschutz', ['pageHero' => true])->name('datenschutz');
Route::view('/barrierefreiheit', 'barrierefreiheit', ['pageHero' => true])->name('barrierefreiheit');
Route::view('/in-arbeit', 'in-arbeit', ['pageHero' => true])->name('in-arbeit');
